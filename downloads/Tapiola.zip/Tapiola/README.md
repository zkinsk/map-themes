Mapsforge rendertheme for LocusMap. Supports OpenAndroMaps. LoMaps V4+ with minor issues.<br>
Menu: ru/en/de.
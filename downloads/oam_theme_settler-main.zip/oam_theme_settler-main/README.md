Mapsforge rendertheme for LocusMap. Support OpenAndroMaps and new LoMaps V4+.<br>
Menu - ru/en/de.

<img src="https://github.com/andrey-nekrasov/oam_theme_settler/assets/97698777/99b3e1a4-763b-405b-9c1d-fb4740cd11a0" width="200">
<img src="https://github.com/andrey-nekrasov/oam_theme_settler/assets/97698777/39830441-a1d4-4a73-8333-8535b0070d73" width="200">
<img src="https://github.com/andrey-nekrasov/oam_theme_settler/assets/97698777/f43a9e78-0e1e-4c75-9e8d-2577f4ddcedd" width="200">
<img src="https://github.com/andrey-nekrasov/oam_theme_settler/assets/97698777/de576552-3261-47e6-9358-aef2e98bfa77" width="200">
<img src="https://github.com/andrey-nekrasov/oam_theme_settler/assets/97698777/af93f3d1-f2bd-40af-95de-6e72fef790fb" width="200">
<img src="https://github.com/andrey-nekrasov/oam_theme_settler/assets/97698777/24ad4748-eca0-4d69-8378-d0bf1b6eb2bc" width="200">
